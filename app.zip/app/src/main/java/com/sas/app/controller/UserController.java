package com.sas.app.controller;


import com.google.gson.Gson;
import com.sas.app.data.UserData;
import com.sas.app.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping(value = "/save",method = RequestMethod.POST)
    public ResponseEntity<String> saveUser(@RequestBody UserData userData){
        log.info("user onboarding request:"+ new Gson().toJson(userData));
        return userService.saveUser(userData);
    }
}
