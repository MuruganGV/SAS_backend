package com.sas.app.data;


import lombok.Value;

@Value
public class UserData {

    private String name;
    private Long mobile;
    private String email;
    private String password;
    private String address;
    private String govtId;
}
