package com.sas.app.dao.entity;

import jakarta.persistence.*;
import lombok.Data;


@Entity
@Data
@Table (name = "users")
public class User {


    @Id
    @Column (name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column (name = "name", nullable = false)
    private String name;

    @Column (name = "mobile", nullable = false)
    private Long mobile;

    @Column (name = "email", nullable = false)
    private String email;

    @Column (name = "password", nullable = false)
    private String password;

    @Column (name = "address", nullable = false)
    private String address;

    @Column (name = "govt_id")
    private String govtId;


}
