package com.sas.app.service;

import com.sas.app.dao.UserRepository;
import com.sas.app.data.UserData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.sas.app.dao.entity.User;

@Service
@Slf4j
public class UserService {

    @Autowired
    UserRepository userRepository;


    public ResponseEntity<String> saveUser(UserData userData){

        try {
            User user = new User();

            user.setName(userData.getName());
            user.setEmail(userData.getEmail());
            user.setMobile(userData.getMobile());
            user.setAddress(userData.getAddress());
            user.setPassword(userData.getPassword());
            user.setGovtId(userData.getGovtId());
            userRepository.save(user);
            return ResponseEntity.ok("user Data Save");
        }catch (Exception e){
            log.error("error in saving user data", e.getCause());
            return ResponseEntity.internalServerError().body("error in saving user data");
        }
    }
}
